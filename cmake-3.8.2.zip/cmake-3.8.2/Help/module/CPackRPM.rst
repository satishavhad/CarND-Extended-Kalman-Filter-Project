.. cmake-module:: ../../Modules/CPackRPM.cmake
