.. cmake-module:: ../../Modules/FindTIFF.cmake
