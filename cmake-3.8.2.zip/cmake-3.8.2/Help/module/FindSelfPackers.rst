.. cmake-module:: ../../Modules/FindSelfPackers.cmake
