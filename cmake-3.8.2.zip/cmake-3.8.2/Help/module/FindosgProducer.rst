.. cmake-module:: ../../Modules/FindosgProducer.cmake
