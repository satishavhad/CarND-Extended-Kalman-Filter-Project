.. cmake-module:: ../../Modules/FindTclStub.cmake
