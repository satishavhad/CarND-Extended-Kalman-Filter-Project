.. cmake-module:: ../../Modules/FortranCInterface.cmake
